-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: May 17, 2018 at 07:15 AM
-- Server version: 10.1.13-MariaDB
-- PHP Version: 5.6.20

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ds`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `username` varchar(20) NOT NULL,
  `passsword` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`username`, `passsword`) VALUES
('admin', '12345'),
('admin', '12345');

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `firstname` varchar(20) DEFAULT NULL,
  `lastname` varchar(20) DEFAULT NULL,
  `username` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL,
  `email` varchar(50) DEFAULT NULL,
  `elective` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`firstname`, `lastname`, `username`, `password`, `email`, `elective`) VALUES
('diganth', 'gowda', '2015lcs005', '1234', 'diganth', NULL),
('varsha', 'gowda', '2015cse153', '1234', 'varshs', NULL),
('abcd', 'efgh', '2015cse155', '1234', 'abcd@a.com', NULL),
('123', '', '', '', '', NULL),
('46546', '656', '2016lcs005', '23523', 'efef', NULL),
('weqgwae', 'aweg', '2015cse159', 'awerty', 'werg3@waef', NULL),
('hari', 'shree', '2016cse155', '123456', 'hari@gmail.com', NULL),
('abcd', 'efgh', '2016lcs006', '123456', 'a@a.com', NULL),
('diganth', 'hgf', '2016lcs005', '123456', 'dignath@gmail.com', NULL),
('suhas', 'KS', '2015cse136', '123456', 'suhasksgbd90@gmail.com', NULL),
('abhay', 'Hm', '2015cse003', '123456', 'sfhjbjfddj', NULL),
('bhavana', 'C', '2015cse029', '123456', 'bhavanavarma757@gmail.com', NULL),
('john', 'S', '2015cse148', '123456', 'john@gmail.com', NULL),
('kiran', 'GOWDA', '2015cse065', '123456', 'kiran@gmail.com', NULL),
('chandan', 'R', '2015cse061', 'DATAMINING', '123456', 'chandan@gmail.com'),
('BHARATH', 'S', '2015cse111', '123456', 'BHARATH@GMAIL.COM', 'DATAMINING');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
