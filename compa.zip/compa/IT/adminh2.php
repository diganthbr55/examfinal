<?php



$dbc = mysqli_connect('localhost','root','','ds') or die('Error connecting to MySQL server.');
$query ="select username, password from login where usename='$username' && =password='$password');
$result=mysqli_query($dbc,$query) or die ('Error querying database');
$rows = mysqli_fetch_all($result);
echo<<<MULTI_LINE_STRING
<div style="display:block;">
<table style="margin-top:0px;">
<tr>
<th>USERNAME</th>
<th>PASSWORD</th>
</tr>
MULTI_LINE_STRING;
foreach ($rows as $row) {
    $username = $row[2];
    $password = $row[3];
}
?>