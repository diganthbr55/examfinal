<?php



$dbc = mysqli_connect('localhost','root','','ds') or die('Error connecting to MySQL server.');

$username = $_POST['username'];
$password = $_POST['password'];
$query = "SELECT * from login where username='$username'";
$result = mysqli_query($dbc, $query) or die ('Error querying database.');
$row = mysqli_fetch_array($result);

session_start();

if($row['username'] == $username && $row['password'] == $password){
    header('location:course.php');
    $_SESSION['user_logged_in']=true;
    $_SESSION['first_name'] = $row['firstname'];
    $_SESSION['user_name'] = $row['username'];
    $_SESSION['elective'] = $row['elective'];
    
}
    else {
    echo "Error u have entered a wrong username or password"."<br>";
    }

echo "<br />";
mysqli_close($dbc);
?>
