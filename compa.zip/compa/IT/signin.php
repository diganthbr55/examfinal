<?php



$dbc = mysqli_connect('localhost', 'root', '', 'ds') or die('Error connecting to MySQL server.');

$firstname = $_POST['firstname'];
$lastname = $_POST['lastname'];
$username = $_POST['username'];

$password = $_POST['password'];
$email = $_POST['email'];
$elective = $_POST['elective'];
$query = "SELECT COUNT(*) as count from login where username='$username' or email='$email'";
$result = mysqli_query($dbc, $query) or die ('Error querying database.');
$row = mysqli_fetch_array($result);

if ($row['count'] > 0) {
    echo 'Error: User name or email address already exists.';
}
else {
    mysqli_query($dbc, "INSERT INTO login VALUES ('$firstname','$lastname','$username','$password','$email','$elective')");

}
mysqli_close($dbc);
echo "student was successfully added";
  //header("Location: login.html");
?>
