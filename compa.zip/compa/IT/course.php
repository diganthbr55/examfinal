<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
body {
    font-family: "Lato", sans-serif;
}
.sidenav {

    height: 100%;
    width: 200px;
    position: fixed;
    z-index: 1;
    top: 0;
    background-color: black;
    overflow-x: hidden;
    padding-top: 20px;
}

.sidenav a, .dropdown-btn {
    padding: 6px 8px 6px 16px;
    text-decoration: none;
    font-size: 20px;
    color: #818181;
    display: block;
    border: none;
    background: none;
    width: 100%;
    text-align: left;
    cursor: pointer;
    outline: none;
}

/* On mouse-over */
.sidenav a:hover, .dropdown-btn:hover {
    color: #f1f1f1;
}

/* Main content */
.main {
    margin-left: 200px; /* Same as the width of the sidenav */
    font-size: 20px; /* Increased text to enable scrolling */
    padding: 0px 10px;
}

/* Add an active class to the active dropdown button */
.active {
    background-color: green;
    color: white;
}

/* Dropdown container (hidden by default). Optional: add a lighter background color and some left padding to change the design of the dropdown content */
.dropdown-container {
    display: none;
    background-color: #262626;
    padding-left: 8px;
}

/* Optional: Style the caret down icon */
.fa-caret-down {
    float: right;
    padding-right: 8px;
}

/* Some media queries for responsiveness */
@media screen and (max-height: 450px) {
    .sidenav {padding-top: 15px;}
    .sidenav a {font-size: 18px;}
}
</style>
</head>
<body>
    

<div class="sidenav">
    
    
  <button class="dropdown-btn">CSE
    <i class="fa fa-caret-down"></i>
  </button>
  <div class="dropdown-container">
    <a href="#">SEM 1</a>
    <a href="#">SEM 2</a>
    <a href="#">SEM 3</a>
    <a href="#">SEM 4</a>
    <a href="#">SEM 5</a>
    <a href="cse.php">SEM 6</a>
    <a href="#">SEM 7</a>
    <a href="#">SEM 8</a>
  </div>
  <button class="dropdown-btn">MEC
    <i class="fa fa-caret-down"></i>
  </button>
  <div class="dropdown-container">
    <a href="#">SEM 1</a>
    <a href="#">SEM 2</a>
    <a href="#">SEM 3</a>
    <a href="#">SEM 4</a>
    <a href="#">SEM 5</a>
    <a href="#">SEM 6</a>
    <a href="#">SEM 7</a>
    <a href="#">SEM 8</a>
  </div>
  <button class="dropdown-btn">ECE
    <i class="fa fa-caret-down"></i>
  </button>
  <div class="dropdown-container">
    <a href="#">SEM 1</a>
    <a href="#">SEM 2</a>
    <a href="#">SEM 3</a>
    <a href="#">SEM 4</a>
    <a href="#">SEM 5</a>
    <a href="#">SEM 6</a>
    <a href="#">SEM 7</a>
    <a href="#">SEM 8</a>
  </div>
  <button class="dropdown-btn">EEE
    <i class="fa fa-caret-down"></i>
  </button>
  <div class="dropdown-container">
    <a href="#">SEM 1</a>
    <a href="#">SEM 2</a>
    <a href="#">SEM 3</a>
    <a href="#">SEM 4</a>
    <a href="#">SEM 5</a>
    <a href="#">SEM 6</a>
    <a href="#">SEM 7</a>
    <a href="#">SEM 8</a>
  </div>
  <button class="dropdown-btn">PET
    <i class="fa fa-caret-down"></i>
  </button>
  <div class="dropdown-container">
    <a href="#">SEM 1</a>
    <a href="#">SEM 2</a>
    <a href="#">SEM 3</a>
    <a href="#">SEM 4</a>
    <a href="#">SEM 5</a>
    <a href="#">SEM 6</a>
    <a href="#">SEM 7</a>
    <a href="#">SEM 8</a>
  </div>
  <button class="dropdown-btn">CIV
    <i class="fa fa-caret-down"></i>
  </button>
  <div class="dropdown-container">
    <a href="#">SEM 1</a>
    <a href="#">SEM 2</a>
    <a href="#">SEM 3</a>
    <a href="#">SEM 4</a>
    <a href="#">SEM 5</a>
    <a href="#">SEM 6</a>
    <a href="#">SEM 7</a>
    <a href="#">SEM 8</a>
  </div>
</div>

<script>
/* Loop through all dropdown buttons to toggle between hiding and showing its dropdown content - This allows the user to have multiple dropdowns without any conflict */
var dropdown = document.getElementsByClassName("dropdown-btn");
var i;

for (i = 0; i < dropdown.length; i++) {
  dropdown[i].addEventListener("click", function() {
    this.classList.toggle("active");
    var dropdownContent = this.nextElementSibling;
    if (dropdownContent.style.display === "block") {
      dropdownContent.style.display = "none";
    } else {
      dropdownContent.style.display = "block";
    }
  });
}
</script>

</body>
</html>