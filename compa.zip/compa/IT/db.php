<?php
$dbhost='localhost';
$dbuser='root';
$dbpassword='';
$dbname='ds';
echo $dbhost."<br />";
echo $dbuser."<br />";
echo $dbpassword."<br />";
echo $dbname."<br />";
$dbh = mysqli_connect($dbhost,$dbuser,$dbpassword,$dbname) or die("error connection to the database".mysqli_error($dbh));
$query="select * from Login";
$result = mysqli_query($dbh,$query) or die("error connection to the database");
echo "successfully connected"."<br />";
//echo'<form id="myform">';
//while($row=mysqli_fetch_array($result,MYSQLI_ASSOC))
//{
//echo '<input type="radio" id="crname" name="candidate"
	//value="'.$row['crname'].'">'.$row['crname'].'</input><br />';
//echo $row['crno']."<br />";
//echo $row['crname']."<br />";
//print_r($row)."<br />";
//}
//echo '</form>';
?>
