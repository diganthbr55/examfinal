<?php

$connection=mysqli_connect('localhost','root','','ds');
if (!$connection)
{
    die("Connection error: ".mysqli_connect_error());
}



        echo("<table><tr><th>firstname</th><th>username</th><th>password</th></tr>");
    
$query="select firstname,username,password from login";
$run=mysqli_query($connection,$query);
while($td=mysqli_fetch_array($run))
{
    
    
    echo("<tr><td>".$td['firstname']."</td><td>".$td['username']."</td><td>".$td['password']."</td>");
}
echo("</table>");
?>