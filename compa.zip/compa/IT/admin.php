<?php



$dbc = mysqli_connect('localhost','root','','ds') or die('Error connecting to MySQL server.');

$username = $_POST['username'];
$passsword = $_POST['passsword'];
$query = "SELECT * from admin where username='$username'";
$result = mysqli_query($dbc, $query) or die ('Error querying database.');
$row = mysqli_fetch_array($result);


if($row['username'] == $username && $row['passsword'] == $passsword){
    header('location:adminh.html');
}
    else {
    echo "Error u have entered a wrong username or password"."<br>";
    }

echo "<br />";
mysqli_close($dbc);
?>
