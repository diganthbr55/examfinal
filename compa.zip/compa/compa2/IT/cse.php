<!DOCTYPE html>
<html>
<head>
<style>
table, th, td {
    border: 1px solid black;
    border-collapse: collapse;
}
th, td {
    padding: 5px;
    text-align: left;
}
</style>
</head>
<body>
  <form action="#" method="post">
<center><h1><b>The following courses offered in this term</b></h1></center>
<?php

session_start();

$dbc = mysqli_connect('localhost','root','','ds') or die('Error connecting to MySQL server.');
$name=$_SESSION['first_name'];
$ID = $_SESSION['user_name'];
    $elective=$_SESSION['elective'];

      echo"NAME: $name";echo"<br/>";
    echo"ID.NO: $ID";echo"<br/>";
          echo"ELECTIVE: $elective";echo"<br/>";
    
    ?>
      <table style="width:100%">
    
  <tr>
    <th>CourseID</th>
    <th>CourseName</th>
  </tr>
  <tr>
    <td>CSE 215</td>
    <td>Cryptography and Network Security</td>
  </tr>
  <tr>
 
    <td>CSE 216</td>
    <td>Software Engineering</td>
  </tr>
  
  <tr>
    <td>CSE 222</td>
    <td>Artificial Intelligence</td>
  </tr>
  <tr>
    <td>CSE 217</td>
    <td>Compiler Design</td>
  </tr>
         <!-- <tr><td>Sem</td>
          <td><select name="sem">
              <option value="1">1</option>
              <option value="2">2</option>
              <option value="3">3</option>
              <option value="4">4</option>
              <option value="5"></option>
              <option value="6"></option>
              <option value="7"></option>
              <option value="8"></option>
              </select></td></tr>-->
</table>
      
    ELECTIVE:
        <SELECT name="el">
    <option VALUE="PARALLEL COMPUTING">PARALLEL COMPUTING</option>
    <option VALUE="DATA MINING">DATA MINING</option>
    <option VALUE="MOBILE COMMUNICATION">MOBILE COMMUNICATION</option></SELECT>
<br />
<br />
      <center><input type="submit" value="submit" name="submit"></input></center>
       </form>
<?php
if(isset($_POST['submit'])){

$dbc = mysqli_connect('localhost','root','','ds') or die('Error connecting to MySQL server.');

    $q=mysqli_query($dbc,"insert into subj (`semid`,`branch`) values ('1','CSE')");
    if($q==1){
        echo '<h5>Succesfully Registered!</h5>';
    }
    else{
        echo "<h4>Unable to Register</h4>";
    }
}
    ?>
    <a href="logout.php">Log out</a>

</body>
</html>
