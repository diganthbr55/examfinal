<?php

session_start();

?>

<html>
<head><title>Add Subjects</title>
    </head>
    <form action="adminh.html">
<table>
    <tr>
        <td>
        Course Code</td><td>
        <input type="text" name="ccode"></input></td></tr>
 <tr>
        <td>
        Course name</td><td>
        <input type="text" name="ccode"></input></td></tr>
 <tr>
        <td>
        Course sem</td><td>
        <input type="text" name="ccode"></input></td></tr>
 <tr>
        <td>
        Branch</td><td>
        <input type="text" name="ccode"></input></td></tr>
    <tr><td><input type="submit" value="submit"></td></tr>
</form>
</table>    
</html>

<?php
